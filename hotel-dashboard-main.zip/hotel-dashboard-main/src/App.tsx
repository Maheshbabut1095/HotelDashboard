import React from 'react';
import Dashboard from './Dashboard';

const App: React.FC = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default App;
